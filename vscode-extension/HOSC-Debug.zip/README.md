# HOSC Language Debug Extension

This extension provides debugging support for the HOSC programming language in Visual Studio Code.

## Features

- Debug HOSC programs directly in VS Code
- Set breakpoints in `.hosc` files
- Step through code execution
- Inspect variables and call stack
- Support for launch configurations

## Prerequisites

- VS Code 1.80.0 or higher
- HOSC compiler and runtime built and available in PATH
- Node.js 20+ (for building the extension)

## Building the Extension

```bash
cd vscode-extension
npm install
npm run compile
```

## Running the Extension

1. Open the `vscode-extension` folder in VS Code
2. Press `F5` to launch a new Extension Development Host window
3. In the new window, open a HOSC project
4. Create a `.vscode/launch.json` file with the following configuration:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "hosc",
      "request": "launch",
      "name": "Debug HOSC Program",
      "program": "${workspaceFolder}/hello.hosc",
      "stopOnEntry": false
    }
  ]
}
```

5. Press `F5` to start debugging

## Debug Configuration

The extension supports the following debug configuration options:

- `program` (required): Path to the HOSC program to debug
- `stopOnEntry` (optional): Automatically stop after launch (default: false)
- `trace` (optional): Enable logging of the debug adapter protocol (default: false)

## Extension Structure

```
vscode-extension/
├── src/
│   ├── extension.ts          # Extension entry point
│   └── debugAdapter.ts       # Debug adapter implementation
├── .vscode/
│   ├── launch.json           # Extension development launch config
│   └── tasks.json            # Build tasks
├── package.json              # Extension manifest
├── tsconfig.json             # TypeScript configuration
└── README.md                 # This file
```

## Debug Adapter Protocol

This extension implements the Debug Adapter Protocol (DAP) to communicate between VS Code and the HOSC runtime. The debug adapter:

- Launches HOSC programs
- Manages breakpoints
- Provides stack traces
- Exposes variable scopes
- Supports stepping operations

## Known Limitations

- This is a bootstrap implementation with basic debugging support
- Advanced features like conditional breakpoints, hit counts, and log points are not yet supported
- Variable inspection is currently limited
- Step debugging is simulated (full implementation requires HOSC VM debug hooks)

## Contributing

See the main [HOSC Language repository](https://github.com/Hyggshi-OS-project-center/HOSC-Language) for contribution guidelines.

## License

Apache License 2.0 - See LICENSE file for details.